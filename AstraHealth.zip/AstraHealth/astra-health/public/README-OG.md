# OG Image Placeholder

This directory should contain `og.png` - an abstract gradient image (1200x630px) for social media previews.

You can create one using:
- Design tools (Figma, Photoshop, etc.)
- Online gradient generators
- Programmatic generation with Canvas API or similar

For now, the metadata references `/og.png` but the actual file needs to be created and placed here.
