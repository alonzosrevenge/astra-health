# Astra Health

## Overview

Astra Health is a dark-themed, single-page marketing website for a stealth design+AI studio focused on transparent clinical reasoning. The project is built as a Next.js 14 App Router application with TypeScript and Tailwind CSS, delivering an editorial, calm, and premium aesthetic. The site features email capture functionality for access requests and showcases the studio's approach to healthcare AI through carefully crafted copy and visual design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Framework
**Decision:** Next.js 14 with App Router  
**Rationale:** App Router provides modern React Server Components architecture, built-in metadata API for SEO, and optimized font loading. The framework choice supports the single-page application requirements while maintaining excellent performance and developer experience.

### Styling Architecture
**Decision:** Tailwind CSS with custom design system  
**Problem addressed:** Need for consistent, maintainable styling with custom brand colors and typography  
**Implementation:**
- Custom color palette defined in `tailwind.config.ts` (ink, slate, graphite, mint)
- Custom utility classes in `globals.css` for gridlines, radial glows, and animations
- Container configuration with responsive padding
- Custom letter-spacing for editorial typography feel

**Design tokens:**
- Background colors: Multi-layered (ink → slate → graphite) for depth
- Accent color: Mint (#BDF8E2) used sparingly for CTAs and highlights
- Typography: Inter font via `next/font/google` for optimized loading
- Opacity-based text hierarchy (70-80% for secondary text)

### Typography System
**Decision:** Inter font family loaded via next/font/google  
**Rationale:** Inter provides excellent readability and editorial feel while next/font optimizes loading with automatic self-hosting, preventing layout shift. The font variable is injected at root level for global access.

**Configuration:**
- CSS custom property: `--font-inter`
- Display swap strategy for optimal performance
- Tight leading and subtle letter-spacing for premium feel

### Component Architecture
**Pattern:** React functional components with TypeScript  
**Structure:**
- `/components` directory for reusable UI elements
- Client components marked with 'use client' directive where needed
- Server components by default for optimal performance

**Key components:**
1. **GlowCard** - Reusable bordered card with hover glow effect for module showcases
2. **BadgeMarquee** - Animated credibility stripe with duplicated content for infinite scroll
3. **EmailCapture** - Form component with state management and async submission

### Animation Strategy
**Decision:** CSS-based animations with reduced-motion support  
**Rationale:** Lightweight approach without additional JavaScript libraries. Respects user accessibility preferences.

**Implementation:**
- Fade-in utility class for progressive content reveal
- Hover states on interactive elements (cards, buttons)
- CSS-only marquee animation
- Opacity and transform transitions for smooth interactions

### Layout Structure
**Pattern:** Single-page sectional layout  
**Sections:**
1. Hero with radial glow background treatment
2. Credibility stripe (marquee)
3. Two-column module showcase (responsive grid)
4. Thesis statement
5. Research notes
6. Footer with contact information

**Responsive approach:**
- Mobile-first design
- Container with responsive padding
- Grid layouts that stack on mobile (`md:grid-cols-2`)

### Metadata & SEO
**Decision:** Next.js built-in Metadata API  
**Configuration:**
- Static metadata in `app/layout.tsx`
- OpenGraph and Twitter card support
- Placeholder OG image reference (`/og.png`)

## External Dependencies

### Third-Party Services

**Formspree (Email Collection)**
- **Purpose:** Handle email capture form submissions without backend infrastructure
- **Integration:** Client-side POST requests to Formspree endpoint
- **Configuration:** Environment variable `NEXT_PUBLIC_FORM_ACTION` for form endpoint URL
- **Status:** Placeholder configuration in code; requires actual Formspree account setup

### NPM Packages

**Core Dependencies:**
- `next@14.2.33` - React framework with App Router
- `react@^18` - UI library
- `react-dom@^18` - React DOM renderer

**Development Dependencies:**
- `typescript@^5` - Type safety and developer experience
- `tailwindcss@^3.4.1` - Utility-first CSS framework
- `postcss@^8` - CSS processing for Tailwind
- `eslint@^8` - Code linting
- `eslint-config-next@14.2.33` - Next.js specific linting rules
- `@types/*` - TypeScript definitions for Node, React, and React DOM

### Font Loading
**Google Fonts Integration:**
- Inter font family loaded via `next/font/google`
- Automatic optimization and self-hosting by Next.js
- Subset: Latin characters only

### Asset Requirements
**Missing assets:**
- `/public/og.png` - Social media preview image (1200x630px recommended)
- Currently referenced in metadata but not present in repository

### Deployment Considerations
**Hosting targets:**
- Designed for Vercel deployment (Next.js native platform)
- Compatible with Replit for development
- Custom server configuration: Binds to `0.0.0.0:5000` for containerized environments

**Environment variables needed:**
- `NEXT_PUBLIC_FORM_ACTION` - Formspree form endpoint URL